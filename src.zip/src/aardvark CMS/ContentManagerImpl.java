/* $Id$
 *
 * Copyright (c) 2003 - 2008 University of Edinburgh.
 * All Rights Reserved
 */
package uk.ac.ed.ph.aardvark.cms.internal;

import uk.ac.ed.ph.aardvark.cms.CheckedOutException;
import uk.ac.ed.ph.aardvark.cms.ContentManager;
import uk.ac.ed.ph.aardvark.cms.ContentManagerException;
import uk.ac.ed.ph.aardvark.cms.DeadNodeException;
import uk.ac.ed.ph.aardvark.cms.DuplicateNodeLinkIdException;
import uk.ac.ed.ph.aardvark.cms.DuplicateNodePathException;
import uk.ac.ed.ph.aardvark.cms.InappropriateResourceTypeException;
import uk.ac.ed.ph.aardvark.cms.InconsistentStateException;
import uk.ac.ed.ph.aardvark.cms.NodeExistsException;
import uk.ac.ed.ph.aardvark.cms.NodeLinkIdBuilder;
import uk.ac.ed.ph.aardvark.cms.NodeNotFoundException;
import uk.ac.ed.ph.aardvark.cms.NodePathCircularityException;
import uk.ac.ed.ph.aardvark.cms.NotAllowedException;
import uk.ac.ed.ph.aardvark.cms.NotLockedException;
import uk.ac.ed.ph.aardvark.cms.ParentNodeCannotHaveChildrenException;
import uk.ac.ed.ph.aardvark.cms.ParentNodeNotFoundException;
import uk.ac.ed.ph.aardvark.cms.ResourceNotFoundException;
import uk.ac.ed.ph.aardvark.cms.domain.ContentNodeIdentifier;
import uk.ac.ed.ph.aardvark.cms.domain.ContentNodePath;
import uk.ac.ed.ph.aardvark.cms.domain.CoreNodeMetadata;
import uk.ac.ed.ph.aardvark.cms.domain.EditableNodeMetadata;
import uk.ac.ed.ph.aardvark.cms.domain.FilesNodeIdentifier;
import uk.ac.ed.ph.aardvark.cms.domain.FilesNodePath;
import uk.ac.ed.ph.aardvark.cms.domain.FullNodeMetadata;
import uk.ac.ed.ph.aardvark.cms.domain.HistoryNodePath;
import uk.ac.ed.ph.aardvark.cms.domain.NodeDependencyType;
import uk.ac.ed.ph.aardvark.cms.domain.NodeInternalId;
import uk.ac.ed.ph.aardvark.cms.domain.NodeLinkId;
import uk.ac.ed.ph.aardvark.cms.domain.NodePath;
import uk.ac.ed.ph.aardvark.cms.domain.Privilege;
import uk.ac.ed.ph.aardvark.cms.domain.ResourcePath;
import uk.ac.ed.ph.aardvark.cms.domain.ResourcePathFilter;
import uk.ac.ed.ph.aardvark.cms.domain.ResourceProductionType;
import uk.ac.ed.ph.aardvark.cms.domain.ResourceType;
import uk.ac.ed.ph.aardvark.cms.domain.VersionNumber;
import uk.ac.ed.ph.aardvark.cms.domain.WorkspaceNodeIdentifier;
import uk.ac.ed.ph.aardvark.cms.domain.WorkspaceNodePath;
import uk.ac.ed.ph.aardvark.cms.domain.transport.NodeDependencyWithSourceInfo;
import uk.ac.ed.ph.aardvark.cms.domain.transport.NodeDependencyWithTargetInfo;
import uk.ac.ed.ph.aardvark.cms.internal.aspects.LockingAspect;
import uk.ac.ed.ph.aardvark.cms.internal.filesystem.FilesystemMetadataManager;
import uk.ac.ed.ph.commons.util.ConstraintUtilities;
import uk.ac.ed.ph.commons.util.LambdaFilter;
import uk.ac.ed.ph.commons.util.ObjectUtilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Default implementation of {@link ContentManager} that uses a {@link MetadataManager}
 * and {@link ResourceManager} together to store the metadata and resources respectively.
 * <p>
 * The CRUD operations in this class are <strong>NOT</strong> Thread-safe. However,
 * by weaving in an AOP-based {@link LockingAspect} aspect, the resulting proxy
 * is Thread-safe.
 *
 * @author  David McKain
 * @version $Revision$
 */
@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED)
public class ContentManagerImpl extends ContentReaderImpl implements ContentManager {

    private static final Log log = LogFactory.getLog(ContentManagerImpl.class);

    /** VersionNumber used for the first revision to a Node when put under version control */
    public static final VersionNumber FIRST_REVISION_VERSION = VersionNumber.VERSION_1_0;

    /** Commit comment automatically applied to first revision when Node is put under version control */
    public static final String FIRST_REVISION_COMMENT = "First revision - Node put under version control";
    
    /** Commit comment automatically applied to final revisions when Node is deleted */
    public static final String FINAL_REVISION_COMMENT = "Node deleted - Original Path was ";

    /** Responsible for managing the underlying resources */
    private ResourceManager resourceManager;

    /** Responsible for managing the underlying metadata */
    private MetadataManager metadataManager;
    
    /** Current NodeLinkIdBuilder property */
    private NodeLinkIdBuilder nodeLinkIdBuilder;

    @Override
    public void init() {
        super.init();
        ConstraintUtilities.ensureNotNull(resourceManager, "resourceManager");
        ConstraintUtilities.ensureNotNull(metadataManager, "metadataManager");
        ConstraintUtilities.ensureNotNull(nodeLinkIdBuilder, "nodeLinkIdBuilder");
    }
    
    //------------------------------------------------------
    // Properties

    /**
     * Gets the underlying ResourceManager that will be managing the underlying
     * Resources.
     * <p>
     * This should only be used for specific "internal" CMS tasks, like cloning
     * a CMS as it violates the facade pattern of this class.
     *
     * @return underlying ResourceManager for this CMS.
     */
    public ResourceManager getResourceManager() {
        return resourceManager;
    }
    
    public void setResourceManager(ResourceManager resourceManager) {
        super.setResourceReader(resourceManager);
        this.resourceManager = resourceManager;
    }

    /**
     * Gets the underlying MetadataManager that will be managing the underlying
     * Resources.
     * <p>
     * This should only be used for specific "internal" CMS tasks, like cloning
     * a CMS as it violates the facade pattern of this class.
     *
     * @return underlying MetadataManager for this CMS.
     */
    public MetadataManager getMetadataManager() {
        return metadataManager;
    }
    
    public void setMetadataManager(MetadataManager metadataManager) {
        super.setMetadataReader(metadataManager);
        this.metadataManager = metadataManager;
    }

 
    public NodeLinkIdBuilder getNodeLinkIdBuilder() {
        return this.nodeLinkIdBuilder;
    }
    
    public void setNodeLinkIdBuilder(NodeLinkIdBuilder nodeLinkIdBuilder) {
        this.nodeLinkIdBuilder = nodeLinkIdBuilder;
    }

    //------------------------------------------------------
    // Implementation of suggestNewNodeLinkId()

    public NodeLinkId suggestNewNodeLinkId(NodeLinkId template) {
        ConstraintUtilities.ensureNotNull(template, "template");
        if (!metadataManager.existsNodeMetadata(template)) {
            return template;
        }
        int i=1;
        String templateBase = template.getValue();
        while (true) {
            template.setValue(templateBase + i);
            if (!metadataManager.existsNodeMetadata(template)) {
                break;
            }
            i++;
        }
        return template;
    }

    //------------------------------------------------------
    // Implementation and helpers for createNode()

    public FullNodeMetadata createNode(EditableNodeMetadata metadata)
            throws DuplicateNodeLinkIdException, DuplicateNodePathException,
            ParentNodeNotFoundException, NotAllowedException, ParentNodeCannotHaveChildrenException {
        /* Check arguments */
        ensureNotNull(metadata);
        ensureNotNull(metadata.getNodePath());
        if (!(metadata.getNodePath() instanceof FilesNodePath)) {
            throw new IllegalArgumentException("New Node must be a Files Node");
        }

        /* Do creation */
        return createNode(metadata, true);
    }

    protected FullNodeMetadata createNode(EditableNodeMetadata metadata, boolean checkPermission)
            throws DuplicateNodeLinkIdException, DuplicateNodePathException,
            ParentNodeNotFoundException, NotAllowedException, ParentNodeCannotHaveChildrenException {
        ContentNodePath nodePath = metadata.getNodePath();
        if (checkPermission) {
            /* Make sure caller is allowed to create Node */
            checkCallerPermission(Privilege.EDITOR, nodePath);
        }
        /* Fill out full metadata template for creation */
        FullNodeMetadata template = MetadataUtilities.createNewEntryTemplate(metadata,
                createTimestamp(), getCurrentUser().getUserId());
        
        /* Will we automatically assign a NodeLinkId? */
        boolean autoCreateNodeLinkId = (nodePath instanceof FilesNodePath && metadata.getLinkId()==null);
        NodeLinkId linkIdTemplate = null;
        if (autoCreateNodeLinkId) {
            /* Create template Link ID. This may not be the actual final Link ID since that
             * may already be in use.
             */
            linkIdTemplate = nodeLinkIdBuilder.createNodeLinkIdTemplate((FilesNodePath) nodePath);
        }

        /* Right, first we do the create at the MetadataManager level since it is much stricter. */
        NodeInternalId internalId = null;
        if (autoCreateNodeLinkId) {
            /* Client has asked us to automatically create Link ID so we'll keep trying until
             * something works OK.
             */
            NodeLinkId linkIdTry;
            for (int suffix=0; true; suffix++) {
                try {
                    linkIdTry = (suffix==0) ? linkIdTemplate : new NodeLinkId(linkIdTemplate.getValue() + suffix);
                    template.setLinkId(linkIdTry);
                    log.debug("Attempting creation with Link ID " + linkIdTry);
                    internalId = metadataManager.createNodeMetadata(template);
                    log.debug("Creation successful!");
                    break;
                }
                catch (DuplicateNodeLinkIdException e) {
                    /* Keep iterating */
                    log.debug("Creation failed - will retry with a new suggestion");
                }
            }
        }
        else {
            /* Client has specified Link ID so only try to create once */
            internalId = metadataManager.createNodeMetadata(template);
        }
        
        /* Right, if here then the Node creation was successful */
        template.setInternalId(internalId);

        /* Now try to do it at the ResourceManager level. If this fails, then
         * we'll try to manually undo what happened above */
        try {
            resourceManager.createStore(nodePath);
        }
        catch (InconsistentStateException e) {
            log.warn("Inconsistent state detected - trying to undo work in MetadataManager");
            try {
                metadataManager.deleteNodeMetadata(internalId);
            }
            catch (NodeNotFoundException eInner) {
                log.error("Could not do manual rollback!");
            }
            throw e;
        }
        return template;
    }
    
    //------------------------------------------------------
    // Implementation and helpers for copyNode() and deepCopyNode()
    
    public FullNodeMetadata copyNode(ContentNodeIdentifier sourceNode, ContentNodePath targetNodePath,
            NodeLinkId targetLinkId)
            throws NodeNotFoundException, NotAllowedException,
            NodeExistsException, DuplicateNodeLinkIdException,
            ParentNodeNotFoundException, ParentNodeCannotHaveChildrenException {
        /* Check sanity of arguments */
        ensureNotNull(sourceNode);
        ensureNotNull(targetNodePath);
        if (!(targetNodePath instanceof FilesNodePath) && targetLinkId!=null) {
            throw new IllegalArgumentException("targetLinkId must be null if targetNodePath is not a Files Node");
        }
        /* Now copy Node, including only EDITABLE Resources */
        return copySingleNode(sourceNode, ResourcePathFilter.EDITABLE_FILTER,
                targetNodePath, targetLinkId, true);
    }

    /**
     * Internal method to do a shallow copy of a Node's metadata and a selection of its
     * Resources, with optional checking of permissions.
     * 
     * @param sourceNode identifies the Node to be copied
     * @param sourceResourcePathFilter identifies which Resources to be copied. If null then
     *   all Resources are copied
     * @param targetNodePath path of the target Node
     * @param targetLinkId link ID of the target Node
     * @param checkPermissions whether to check permissions or not.
     */
    protected FullNodeMetadata copySingleNode(ContentNodeIdentifier sourceNode,
            LambdaFilter<ResourcePath> sourceResourcePathFilter,
            ContentNodePath targetNodePath, NodeLinkId targetLinkId, boolean checkPermissions)
            throws NodeNotFoundException, NotAllowedException,
            ParentNodeNotFoundException, NodeExistsException,
            DuplicateNodeLinkIdException, ParentNodeCannotHaveChildrenException {
        /* Do first part of copy, which involves looking up and checking access to source Node */
        FullNodeMetadata sourceMetadata = doGetCopySource(sourceNode, checkPermissions);
        
        /* Then perform the actual copy */
        return doFinishCopy(sourceMetadata, sourceResourcePathFilter, 
                targetNodePath, targetLinkId, checkPermissions);
    }

    /**
     * Retrives the "source" of a copy operation, with optional check that the caller has the
     * required Privileges on this Node.
     */
    protected FullNodeMetadata doGetCopySource(ContentNodeIdentifier sourceNode, boolean checkPermissions)
            throws NodeNotFoundException, NotAllowedException {
        /* Look up original metadata */
        FullNodeMetadata sourceMetadata = doGetFullNodeMetadata(sourceNode);
        ContentNodePath sourceNodePath = sourceMetadata.getNodePath();

        /* Make sure caller is allowed to read the source Node */
        if (checkPermissions) {
            checkCallerPermission(Privilege.VIEWER, sourceNodePath);
        }
        return sourceMetadata;
    }

    /**
     * Finishes off a shallow copy, performing an optional check that the caller has the
     * required Privileges on the target Node.
     * 
     * @param sourceMetadata metadata of the Node being copied.
     * @param sourceResourcePathFilter identifies which Resources to be copied. If null then
     *   all Resources are copied
     * @param targetNodePath path of the target Node
     * @param targetLinkId link ID of the target Node
     * @param checkPermissions whether to check permissions or not.
     */
    protected FullNodeMetadata doFinishCopy(FullNodeMetadata sourceMetadata,
            LambdaFilter<ResourcePath> sourceResourcePathFilter,
            ContentNodePath targetNodePath, NodeLinkId targetLinkId, boolean checkPermissions)
            throws NodeExistsException, DuplicateNodeLinkIdException, ParentNodeNotFoundException,
            NotAllowedException, ParentNodeCannotHaveChildrenException {
        /* Make sure the target does not already exist */
        if (metadataManager.existsNodeMetadata(targetNodePath)) {
            throw new NodeExistsException(targetNodePath);
        }
        
        /* Create appropriate template for copying the metadata */
        /*
         * Make a copy of the metadata with supplied new properties replacing
         * the old one. Note that the targetLinkId may be null here, it will be filled in
         * automatically by createNode().
         */
        FullNodeMetadata newMetadata = MetadataUtilities.createCopyTemplate(sourceMetadata,
                targetNodePath, targetLinkId, createTimestamp(), getCurrentUser().getUserId());

        /* Target Node needs created */
        try {
            newMetadata = createNode(newMetadata, checkPermissions);
        }
        catch (DuplicateNodePathException e) {
            /* This should have been tested for in logic above */
            fireUnexpectedException(e);
        }

        /* Finally Copy resources over */
        copyResources(sourceMetadata.getNodePath(), sourceResourcePathFilter, targetNodePath);

        /* That's it */
        return newMetadata;
    }
    
    public FullNodeMetadata deepCopyNode(ContentNodeIdentifier sourceNode, FilesNodePath targetNodePath)
            throws NodeNotFoundException, NotAllowedException,
            NodeExistsException, DuplicateNodeLinkIdException,
            ParentNodeNotFoundException, ParentNodeCannotHaveChildrenException {
        /* Check sanity of arguments */
        ensureNotNull(sourceNode);
        ensureNotNull(targetNodePath);
        
        /* First of all, we traverse the source tree to make sure everything is readable and
         * get the metadata of what we are copying. We'll also build up the resulting paths
         * in the target tree and check we have appropriate privileges on them. Only then
         * do we actually copy stuff.
         */
        List<FullNodeMetadata> sources = new ArrayList<FullNodeMetadata>();
        List<FilesNodePath> targetPaths = new ArrayList<FilesNodePath>();
        doDeepCopyOrMovePrecheck(sourceNode, targetNodePath, sources, targetPaths);
        
        /* Now we simply copy each Node in order. Since we've checked permissions on target
         * Nodes, there's no reason to repeat this here. */
        int numNodes = sources.size();
        if (log.isDebugEnabled()) {
            log.debug("Deep Copy will copy " + numNodes + " Node(s)");
        }
        FullNodeMetadata sourceTreeNodeMetadata, targetTreeNodeMetadata, result = null;
        FilesNodePath targetTreeNodePath;
        for (int i=0; i<numNodes; i++) {
            sourceTreeNodeMetadata = sources.get(i);
            targetTreeNodePath = targetPaths.get(i);
            targetTreeNodeMetadata = doFinishCopy(sourceTreeNodeMetadata,
                    ResourcePathFilter.EDITABLE_FILTER, targetTreeNodePath,
                    null, false);
            if (i==0) {
                /* Return metadata of newly created top Node */
                result = targetTreeNodeMetadata;
            }
        }
        return result;
    }
    
    /**
     * Helper to ensure that a deep copy or move operation will succeed by traversing the subtree
     * specified by the given sourceNode and resulting subtree that would be created at
     * targetNodePath, building up metadata and checking privileges.
     */
    protected void doDeepCopyOrMovePrecheck(ContentNodeIdentifier sourceNode, FilesNodePath targetNodePath,
            List<FullNodeMetadata> sources,  List<FilesNodePath> targetPaths)
            throws NodeNotFoundException, NotAllowedException {
        /* Look up Source and make sure we have access to it */
        FullNodeMetadata sourceMetadata = doGetCopySource(sourceNode, true);
        
        /* Make sure we're allowed to write to target path */
        checkCallerPermission(Privilege.EDITOR, targetNodePath);
        
        /* Record what we found */
        sources.add(sourceMetadata);
        targetPaths.add(targetNodePath);
        
        /* Traverse into child Nodes */
        if (sourceMetadata.getNodeType().getAllowsChildren()) {
            FilesNodePath targetChildPath;
            NodePath[] sourceChildNodePaths = resourceManager.getChildNodePaths(sourceMetadata.getNodePath());
            for (NodePath sourceChildNodePath : sourceChildNodePaths) {
                targetChildPath = (FilesNodePath) targetNodePath.createChildNodePath(sourceChildNodePath.getLastComponent());
                doDeepCopyOrMovePrecheck((ContentNodePath) sourceChildNodePath, targetChildPath, sources, targetPaths);
            }
        }
    }
    
    /**
     * Internal helper method that expects to copy a single Node (without descending into children)
     * without failure.
     * <p>
     * @param sourceNode identifies the Node to be copied
     * @param sourceResourcePathFilter identifies which Resources to be copied. If null then
     *   all Resources are copied
     * @param targetNodePath path of the target Node
     * @param targetLinkId link ID of the target Node
     *   
     * @return FullNodeMetadata of the newly created target Node
     */
    protected FullNodeMetadata ensureCopySingleNode(ContentNodeIdentifier sourceNode,
            LambdaFilter<ResourcePath> sourceResourcePathFilter,
            ContentNodePath targetNodePath, NodeLinkId targetLinkId) {
        FullNodeMetadata result = null;
        try {
            result = copySingleNode(sourceNode, sourceResourcePathFilter,
                    targetNodePath, targetLinkId, false);
        }
        catch (Exception e) {
            fireUnexpectedException(e);
        }
        return result;
    }

    /**
     * Helper method to copy all Editable Resources from a given Node to another Node, handling
     * any Exceptions that may arise as appropriate under the assumption that the caller knows
     * what he is doing.
     * 
     * @param sourcePath identifies the Node to be copied
     * @param sourceResourcePathFilter identifies which Resources to be copied. If null then
     *   all Resources are copied
     * @param targetPath path of the target Node
     */
    protected void copyResources(ContentNodePath sourcePath,
            LambdaFilter<ResourcePath> sourceResourcePathFilter,
            ContentNodePath targetPath) {
        if (log.isDebugEnabled()) {
            log.debug("Copying resources from Node at " + sourcePath + " to " + targetPath
                    + " using filter " + sourceResourcePathFilter);
        }
        /* Go through each Resource and copy the ones which match our filter (or all if no filter
         * is specified).
         */
        try {
            ResourcePath[] sourceResourcePathss = resourceManager.getResourcePaths(sourcePath);
            for (ResourcePath sourceResourcePath : sourceResourcePathss) {
                if (sourceResourcePathFilter==null || sourceResourcePathFilter.accept(sourceResourcePath)) {
                    copyResource(sourceResourcePath, targetPath);
                }
            }
        }
        catch (NodeNotFoundException e) {
            fireUnexpectedException(e);
        }
    }

    /**
     * Helper method to copy a single Resource from a given Node to another Node, handling
     * any Exceptions that may arise as appropriate under the assumption that the caller knows
     * what he is doing.
     */
    protected void copyResource(ResourcePath sourceResource, ContentNodePath destPath) {
        if (log.isDebugEnabled()) {
            log.debug("Copying resource " + sourceResource + " to Node " + destPath);
        }
        ResourcePath destResourcePath = new ResourcePath(destPath, sourceResource.getResourceName(),
                sourceResource.getInnerResourcePath());
        FileInputStream sourceStream;
        try {
            sourceStream = resourceManager.readResource(sourceResource);
            resourceManager.saveResource(destResourcePath, sourceStream);
        }
        catch (Exception e) {
            fireUnexpectedException(e);
        }
    }
    
    //------------------------------------------------------
    // Implementation of moveNode()
    
    public FullNodeMetadata moveNode(FilesNodeIdentifier sourceNode, FilesNodePath targetNodePath)
            throws NodeNotFoundException, NotAllowedException, NodeExistsException,
            ParentNodeNotFoundException, ParentNodeCannotHaveChildrenException,
            NodePathCircularityException {
        /* First check arguments are not null */
        ensureNotNull(sourceNode);
        ensureNotNull(targetNodePath);

        /* First of all, we traverse the source tree to make sure everything is
         * readable and get the metadata of what we are copying. We'll also
         * build up the resulting paths in the target tree and check we have
         * appropriate privileges on them. Only then do we actually copy stuff.
         */
        List<FullNodeMetadata> sources = new ArrayList<FullNodeMetadata>();
        List<FilesNodePath> targetPaths = new ArrayList<FilesNodePath>();
        doDeepCopyOrMovePrecheck(sourceNode, targetNodePath, sources, targetPaths);

        /* Unlike the deep copy, we don't actually need some of the information
         * that was gathered here.
         */
        FullNodeMetadata sourceMetadata = sources.get(0);
        ContentNodePath sourceNodePath = sourceMetadata.getNodePath();
        sources.clear();

        /* Make sure the target does not already exist */
        if (metadataManager.existsNodeMetadata(targetNodePath)) {
            throw new NodeExistsException(targetNodePath);
        }

        /* Move metadata (which will check parentage and circularity for us) */
        sourceMetadata.setNodePath(targetNodePath);
        try {
            metadataManager.updateNodeMetadata(sourceMetadata);
        }
        catch (DuplicateNodeLinkIdException e) {
            /* Should not happen */
            fireUnexpectedException(e);
        }
        catch (DuplicateNodePathException e) {
            /* Should not happen */
            fireUnexpectedException(e);
        }

        /* Now we move the resources. This is normally just a case of
         * delegating to resourceManager directly. However, if we're using the
         * FilesystemMetadataManager with the same root as the resourceManager
         * then it gets a bit complicated since the
         * metadataManager.updateNodeMetadata() above will have have moved the
         * Node (but not its resources) in the resourceManager. In this case, we
         * must copy the remaining Resources over and delete the original Node.
         * 
         * FIXME: This is smelly! Maybe in future we should not allow the FsMM
         * and SFSS share the same root???
         */
        if (metadataManager instanceof FilesystemMetadataManager
                && resourceManager.existsStore(targetNodePath)) {
            copyResources(sourceNodePath, null, targetNodePath);
            resourceManager.deleteStore(sourceNodePath);
        }
        else {
            /* This is the most common situation here */
            resourceManager.moveStore(sourceNodePath, targetNodePath);
        }
        
        /* Finally we remove cached views of ALL target Nodes. We need to do this as they may
         * contain resolved paths which will need updated to reflect the new Node location in
         * the hierarchy.
         */
        for (ContentNodePath targetPath : targetPaths) {
            deleteCachedResources(targetPath);
        }

        /* That's it! */
        return sourceMetadata;
    }
    
    //------------------------------------------------------
    // Implementation of setNodePosition()

    public FullNodeMetadata setNodePosition(FilesNodePath nodePath, int position)
            throws NodeNotFoundException, NotAllowedException {
        ensureNotNull(nodePath);

        /* Get at parent path */
        NodePath parentNodePath = nodePath.getParentNodePath();

        /* Make sure parent path is also a FilesNodePath */
        if (!(parentNodePath instanceof FilesNodePath)) {
            throw new IllegalArgumentException("Node being moved must be the child of a FilesNode");
        }
        /* Make sure caller is allowed to do this */
        checkCallerPermission(Privilege.EDITOR, (ContentNodePath) parentNodePath);

        if (log.isDebugEnabled()) {
            log.debug("Setting position of " + nodePath + " within siblings to " + position);
        }
        /* Read in metadata so we can "touch" it appropriately */
        FullNodeMetadata metadata = touchMetadata(nodePath);

        /* Then simply delegate to the ResourceManager */
        resourceManager.setStorePosition(nodePath, position);

        return metadata;
    }

    //------------------------------------------------------
    // Implementations of deleteNode() in its various guises

    public int deleteNode(ContentNodeIdentifier nodeIdentifier)
            throws NodeNotFoundException, NotAllowedException {
        ensureNotNull(nodeIdentifier);
        return deleteNode(nodeIdentifier, false);
    }
    
    public int deleteNode(FilesNodeIdentifier nodeIdentifier, boolean createRevisions)
            throws NodeNotFoundException, NotAllowedException {
        ensureNotNull(nodeIdentifier);
        return deleteNode((ContentNodeIdentifier) nodeIdentifier, true);
    }

    /**
     * This does the actual work of deleting Nodes.
     * 
     * @param nodeIdentifier ID of the Node to delete
     * @param createRevisions whether to create revisions for the Node or not
     * @return number of Nodes deleted.
     * @throws NodeNotFoundException
     * @throws NotAllowedException
     */
    protected int deleteNode(ContentNodeIdentifier nodeIdentifier, boolean createRevisions)
            throws NodeNotFoundException, NotAllowedException {
        /* NOTE: This is quite easy if we don't worry about not being able to rollback
         * if one of the underlying processes fails!
         */
        /* First need to look up the metadata of the top Node being deleted */
        FullNodeMetadata nodeMetadata = doGetFullNodeMetadata(nodeIdentifier);
        ContentNodePath nodePath = nodeMetadata.getNodePath();
        
        /* Make sure caller is allowed to delete Node and its descendants. This has the
         * side effect of listing all Nodes that will be deleted here.
         */
        List<ContentNodePath> nodePathsToBeDeleted = new ArrayList<ContentNodePath>();
        doDeleteNodePrecheck(nodePath, nodePathsToBeDeleted);
        
        /* Will we be creating final revisions? */
        boolean willCreateFinalRevisions = createRevisions && nodePath instanceof FilesNodePath;
        
        return doDeleteNode(nodeMetadata, nodePathsToBeDeleted, willCreateFinalRevisions);
    }
    
    /**
     * Helper to ensure that the caller has permission to delete the Node at the given path,
     * traversing into descendants of the Node as appropriate. All Nodes discovered are added
     * to the wouldBeDeleted List.
     */
    protected void doDeleteNodePrecheck(ContentNodePath nodePath, List<ContentNodePath> wouldBeDeleted)
            throws NodeNotFoundException, NotAllowedException {
        /* Make sure we're allowed to write to target path */
        checkCallerPermission(Privilege.EDITOR, nodePath);
        
        /* Record what we found */
        wouldBeDeleted.add(nodePath);
        
        /* Traverse into child Nodes */
        for (NodePath childNodePath : resourceManager.getChildNodePaths(nodePath)) {
            doDeleteNodePrecheck((ContentNodePath) childNodePath, wouldBeDeleted);
        }
    }
    
    /**
     * Does the job of correctly deleting the given List of Nodes nodePathsToBeDeleted, starting
     * with the top Node having the given metadata topNodeMetadata, without checking access
     * permissions. Dependencies will be removed ahead of deletion and final revisions can be
     * created optionally if specified by the caller (for any Files Nodes that are being deleted
     * here.)
     * 
     * @param topNodeMetadata
     * @param nodePathsToBeDeleted
     * @param willCreateFinalRevisions
     * @return number of Nodes that were deleted
     * @throws NodeNotFoundException
     */
    protected int doDeleteNode(FullNodeMetadata topNodeMetadata,
            List<ContentNodePath> nodePathsToBeDeleted,
            boolean willCreateFinalRevisions)
            throws NodeNotFoundException {
        /* Now traverse the List of Nodes to be deleted, removing dependencies and maybe
         * creating final revisions.
         */
        doRemoveDepsAndMaybeCreateFinalRevisions(topNodeMetadata, nodePathsToBeDeleted, willCreateFinalRevisions);
        
        /* We do the deletion at the filesystem level first */
        resourceManager.deleteStore(topNodeMetadata.getNodePath());

        /* Then we delete at the metadata level */
        return metadataManager.deleteNodeMetadata(topNodeMetadata.getInternalId());
    }
    
    /**
     * Helper to traverse the List of Nodes filled in by {@link #doDeleteNodePrecheck(ContentNodePath, List)},
     * removing all Dependencies that have these Nodes as one of there endpoints. This will also
     * conditionally create a final revision for the Node if requested.
     * 
     * @param topNodeMetadata metadata for the "top" Node in the tree that will be deleted
     *   (we pass this to save looking up IDs again)
     * @param nodePathsToBeDeleted paths of all Nodes to be deleted.
     * @param willCreateFinalRevisions
     */
    private void doRemoveDepsAndMaybeCreateFinalRevisions(FullNodeMetadata topNodeMetadata,
            List<ContentNodePath> nodePathsToBeDeleted,
            boolean willCreateFinalRevisions) {
        NodeInternalId nodeInternalId;
        HistoryNodePath[] historyNodes;
        Date timestamp = createTimestamp();
        FullNodeMetadata history;
        FullNodeMetadata condemnedNodeMetadata;
        /* We simply go through each Node in turn */
        for (ContentNodePath condemnedNodePath : nodePathsToBeDeleted) {
            /* Get Node's internal ID. Note that we already have this information for the top Node
             * so we can save a lookup in this case.
             */
            condemnedNodeMetadata = topNodeMetadata.getNodePath().equals(condemnedNodePath)
                ? topNodeMetadata : metadataManager.getFullMetadata(condemnedNodePath);
            nodeInternalId = condemnedNodeMetadata.getInternalId();
                    
            /* Remove dependencies */
            if (log.isDebugEnabled()) {
                log.debug("Deleting dependencies which have " + nodeInternalId + " as an endpoint");
            }
            nodeDependencyDao.setDependenciesForSource(nodeInternalId, null);
            nodeDependencyDao.setDependenciesForTarget(null, nodeInternalId);
            
            /* Maybe create final revision */
            if (willCreateFinalRevisions && condemnedNodePath instanceof FilesNodePath) {
                /* Look up current history and create minor revision (or 1.0 if no revisions have
                 * been made as yet)
                 */
                historyNodes = getHistoryNodes(nodeInternalId);
                VersionNumber finalVersionNumber = VersionNumber.VERSION_1_0;
                if (historyNodes.length>0) {
                    finalVersionNumber = historyNodes[historyNodes.length-1].getVersionNumber().incrementMinorNumber();
                }
                /* Now create revision */
                history = doCreateRevisionFromFilesNode(condemnedNodeMetadata, finalVersionNumber,
                        createFinalRevisionComment((FilesNodePath) condemnedNodePath), timestamp, false);
                log.info("Created final revision of Node at " + condemnedNodePath
                        + "; history ID is " + history.getInternalId());
            }
        }
    }
    
    /**
     * Creates a commit comment for final revision of the given Node before deletion. This comment
     * contains details about where the Node used to live as this information will be lost
     * after deletion.
     * 
     * @param nodePath
     */
    protected static String createFinalRevisionComment(FilesNodePath nodePath) {
        return FINAL_REVISION_COMMENT + nodePath.toString();
    }
    
    //------------------------------------------------------
    // Implementation of updateNodeMetadata()

    public FullNodeMetadata updateNodeMetadata(EditableNodeMetadata updatedMetadata)
            throws NodeNotFoundException, DuplicateNodeLinkIdException, NotAllowedException {
        return updateNodeMetadata(updatedMetadata, true);
    }

    /**
     * Version of {@link #updateNodeMetadata(EditableNodeMetadata)} that does an optional
     * check on the caller's role.
     *
     * @param updatedMetadata
     * @param checkCaller
     * @throws NodeNotFoundException
     * @throws DuplicateNodeLinkIdException
     * @throws NotAllowedException
     */
    public FullNodeMetadata updateNodeMetadata(EditableNodeMetadata updatedMetadata, boolean checkCaller)
            throws NodeNotFoundException, DuplicateNodeLinkIdException, NotAllowedException {
        if (checkCaller) {
            ensureNotNull(updatedMetadata);
        }
        NodeInternalId internalId = updatedMetadata.getInternalId();
        ContentNodePath updatedNodePath = updatedMetadata.getNodePath();
        if (internalId==null) {
            throw new IllegalArgumentException("Supplied Metadata has a null internal ID - cannot look up Node to change");
        }
        if (checkCaller) {
            /* Make sure the caller can write to the target Node */
            checkCallerPermission(Privilege.EDITOR, updatedNodePath);
        }

        /* Get the existing metadata and make sure that we haven't changed things
         * we shouldn't have changed.
         */
        FullNodeMetadata metadata = doGetFullNodeMetadata(internalId);
        NodeLinkId originalLinkId = metadata.getLinkId();
        if (!metadata.getNodePath().equals(updatedNodePath)) {
            throw new IllegalArgumentException("Cannot change nodePath property");
        }
        else if (!metadata.getNodeType().equals(updatedMetadata.getNodeType())) {
            throw new IllegalArgumentException("Cannot change nodeType property");
        }
        /* Merge the updates into the existing metadata */
        MetadataUtilities.applyEditableUpdates(metadata, updatedMetadata, createTimestamp(),
                getCurrentUser().getUserId());
        
        /* Now simply delegate */
        if (log.isDebugEnabled()) {
            log.debug("Updating metadata for Node at " + updatedNodePath);
        }
        try {
            metadataManager.updateNodeMetadata(metadata);
        }
        catch (DuplicateNodePathException e) {
            /* Can't happen as we explicitly checked for this */
            fireUnexpectedException(e);
        }
        catch (ParentNodeNotFoundException e) {
            /* Can't happen */
            fireUnexpectedException(e);
        }
        catch (ParentNodeCannotHaveChildrenException e) {
            /* Can't happen */
            fireUnexpectedException(e);
        }
        catch (NodePathCircularityException e) {
            /* Can't happen */
            fireUnexpectedException(e);
        }
        
        /* See whether we changed Link IDs or not. If so, we'll invalidate this Node */
        boolean changedLinkId = !ObjectUtilities.nullSafeEquals(originalLinkId, metadata.getLinkId());
        if (changedLinkId) {
            doStartDependencyGraphTraversal(metadata, NodeDependencyType.INVALIDATE_SOURCE_ON_TARGET_CHANGE);
        }
        return metadata;
    }

    //------------------------------------------------------
    // Implementation of checkoutNode()

    public WorkspaceNodePath checkoutNode(FilesNodeIdentifier nodeIdentifier)
            throws NodeNotFoundException, NotAllowedException, CheckedOutException {
        ensureNotNull(nodeIdentifier);
        if (log.isDebugEnabled()) {
            log.debug("Checking out Node " + nodeIdentifier);
        }
        /* Get the Node's current metadata and check that the caller can perform this operation */
        FullNodeMetadata nodeMetadata = doGetFullNodeMetadata(nodeIdentifier);
        NodeInternalId nodeInternalId = nodeMetadata.getInternalId();
        ContentNodePath nodePath = nodeMetadata.getNodePath();
        checkCallerPermission(Privilege.EDITOR, nodePath);

        /* Make sure that the Node is not already locked */
        if (nodeMetadata.getLockHolderUserId()!=null) {
            throw new CheckedOutException(nodeIdentifier);
        }
        /* For sanity purposes, make sure that the Node is not already in someone's workspace */
        NodePath[] userPaths;
        try {
            userPaths = resourceManager.getChildNodePaths(NodePath.WORKSPACE_ROOT_PATH);
        }
        catch (NodeNotFoundException e) {
            throw new ContentManagerException("Could not find workspace base in ResourceManager", e);
        }
        for (int i=0; i<userPaths.length; i++) {
            WorkspaceNodePath workspacePath = new WorkspaceNodePath(userPaths[i].getLastComponent(),
                    nodeInternalId);
            if (resourceManager.existsStore(workspacePath)) {
                throw new ContentManagerException("Node not locked but edits found at " + workspacePath);
            }
        }
        /* Create timestamp for these operations */
        Date timestamp = createTimestamp();
        String userId = getCurrentUser().getUserId();

        /* Check whether a revision has already been created */
        NodePath[] historyPaths = getHistoryNodes(nodeInternalId);
        if (historyPaths.length==0) {
            /* Create revision, update nodeMetadata Object but don't save yet as we'll make
             * further changes below.
             */ 
            log.debug("Creating first revision of Node before checking out");
            doCreateRevisionFromFilesNode(nodeMetadata, FIRST_REVISION_VERSION,
                    FIRST_REVISION_COMMENT, timestamp, false);
        }
        /* Make a copy of the original Node in the caller's workspace, copying only
         * EDITABLE Resources over
         */
        WorkspaceNodePath workspaceNodePath = new WorkspaceNodePath(userId, nodeInternalId);
        if (log.isDebugEnabled()) {
            log.debug("Creating new Workspace Node at " + workspaceNodePath);
        }
        ensureCopySingleNode(nodeInternalId, ResourcePathFilter.EDITABLE_FILTER, workspaceNodePath, null);

        /* Update the Node's metadata to ensure that it is locked */
        nodeMetadata.setLockHolderUserId(userId);
        nodeMetadata.setLockTime(timestamp);
        try {
            metadataManager.updateNodeMetadata(nodeMetadata);
        }
        catch (Exception e) {
            /* (Nothing should go wrong!) */
            fireUnexpectedException(e);
        }

        /* That's it */
        return workspaceNodePath;
    }

    //------------------------------------------------------
    // Implementation of checkinNode()

    public FullNodeMetadata checkinNode(WorkspaceNodeIdentifier workspaceNodeId, VersionNumber versionNumber, String commitComment)
            throws NodeNotFoundException, NotAllowedException, DeadNodeException, NotLockedException {
        /* Do commitNode() as normal */
        FullNodeMetadata[] metadatas = commitNode(workspaceNodeId, versionNumber, commitComment, true);
        FullNodeMetadata result = metadatas[0];
        FullNodeMetadata worspaceMetadata = metadatas[2];
        
        /* Now delete the workspace Node */
        doDeleteWorkspaceNode(worspaceMetadata);
        
        /* Return the updated version of the original Node's metadata */
        return result;
    }
    
    //------------------------------------------------------
    // Implementation of createRevision()

    public HistoryNodePath createRevision(FilesNodeIdentifier nodeId, VersionNumber versionNumber, String commitComment)
            throws NodeNotFoundException, NotAllowedException {
        /* Check arguments */
        ensureNotNull(nodeId);
        ConstraintUtilities.ensureNotNull(versionNumber, "VersionNumber");
        ConstraintUtilities.ensureNotNull(commitComment, "Commit Comment");

        /* First we need to get the metadata of the Node being revised. We won't check
         * Privileges at this point as the getFullNodeMetadata() only checks for VIEWER
         * Privileges.
         */
        FullNodeMetadata nodeMetadata = doGetFullNodeMetadata(nodeId);
        
        /* Now check privileges */
        checkCallerPermission(Privilege.EDITOR, nodeMetadata.getNodePath());
        
        /* Now create History Node with appropriate metadata and Resources, updating and
         * saving the metadata of "this" Node as appropriate.
         */
        FullNodeMetadata historyMetadata = doCreateRevisionFromFilesNode(nodeMetadata,
                versionNumber, commitComment, createTimestamp(), true);
        
        return (HistoryNodePath) historyMetadata.getNodePath();
    }

    /**
     * This does the job of creating the resulting History Node for the newly specified revision
     * of the Files Node having the given metadata.
     * <p>
     * It has a side effect of updating filesNodeMetadata so that it is sync with this new
     * revision. If saveMetadata is true, then the resulting filesNodeMetadata will also be
     * saved to the MetadataManager
     * 
     * @param filesNodeMetadata
     * @param versionNumber
     * @param commitComment
     * @param timestamp
     * @param saveMetadata whether to save resulting metadata to MetadataManager or not. This
     *   is for performance as some operations call this and then do a save later and it's silly
     *   to repeat the operation.
     * 
     * @return metadata of the newly created History Node
     */
    protected FullNodeMetadata doCreateRevisionFromFilesNode(FullNodeMetadata filesNodeMetadata,
            VersionNumber versionNumber, String commitComment, Date timestamp,
            boolean saveMetadata) {
        /* Create new revision and copy edits to it */
        NodeInternalId filesNodeId = filesNodeMetadata.getInternalId();
        HistoryNodePath newCommitPath = new HistoryNodePath(filesNodeId, versionNumber);
        FullNodeMetadata historyMetadata = ensureCopySingleNode(filesNodeId,
                ResourcePathFilter.EDITABLE_FILTER, newCommitPath, null);

        /* Update metadata for new history Node to reflect the given commit details */
        String currentUserId = getCurrentUser().getUserId();
        updateRevisionMetadata(historyMetadata, timestamp, currentUserId,
                versionNumber, commitComment, false);
        
        /* Update metadata for the original Files Node to reflect the new revision state */
        filesNodeMetadata.setCommitComment(commitComment);
        filesNodeMetadata.setVersionNumber(versionNumber);
        filesNodeMetadata.setCommitTime(timestamp);
        filesNodeMetadata.setCommitterUserId(currentUserId);
        if (saveMetadata) {
            expectUpdateFullMetadata(filesNodeMetadata);
        }

        /* Finally, return the metadata of the newly created History Node */
        return historyMetadata;
    }

    //------------------------------------------------------
    // Implementation of commitNode()

    public FullNodeMetadata commitNode(WorkspaceNodeIdentifier workspaceNodeId, VersionNumber versionNumber, String commitComment)
            throws NodeNotFoundException, DeadNodeException, NotAllowedException, NotLockedException {
        return commitNode(workspaceNodeId, versionNumber, commitComment, false)[0];
    }

    /**
     * Internal version of {@link #commitNode(WorkspaceNodeIdentifier, VersionNumber, String)}
     * which optionally unlocks the original Node afterwards. This is used so that the same
     * underlying logic can be used for both
     * {@link #checkinNode(WorkspaceNodeIdentifier, VersionNumber, String)}
     * and {@link #commitNode(WorkspaceNodeIdentifier, VersionNumber, String)}.
     *
     * @param workspaceNodeId
     * @param versionNumber
     * @param commitComment
     * @param unlockOriginalNode
     * 
     * @return an array of 3 elements <tt>{ updatedFilesNodeMetadata,
     *   newHistoryNodeMetadata,
     *   workspaceNodeMetadata }</tt>
     * 
     * @throws NodeNotFoundException
     * @throws DeadNodeException
     * @throws NotAllowedException
     * @throws NotLockedException
     */
    protected FullNodeMetadata[] commitNode(WorkspaceNodeIdentifier workspaceNodeId, VersionNumber versionNumber,
            String commitComment, boolean unlockOriginalNode)
            throws NodeNotFoundException, DeadNodeException, NotAllowedException, NotLockedException {
        ensureNotNull(workspaceNodeId);
        ConstraintUtilities.ensureNotNull(versionNumber, "Version Number");
        ConstraintUtilities.ensureNotNull(commitComment, "Commit Comment");

        /* Look up the metadata of the workspace Node */
        FullNodeMetadata workspaceMetadata = doGetFullNodeMetadata(workspaceNodeId);
        NodeInternalId workspaceInternalId = workspaceMetadata.getInternalId();
        WorkspaceNodePath workspaceNodePath = (WorkspaceNodePath) workspaceMetadata.getNodePath();

        /* Make sure workspace current User has VIEWER Privileges on workspace Node */
        checkCallerPermission(Privilege.VIEWER, workspaceNodePath);

        /* Need a timestamp for this edit */
        Date timestamp = createTimestamp();

        /* Which Node was the caller editing? */
        NodeInternalId originalNodeId = workspaceNodePath.getFilesNodeId();

        /* Make sure the original Node still exists */
        FullNodeMetadata originalMetadata;
        try {
            originalMetadata = doGetFullNodeMetadata(originalNodeId);
        }
        catch (NodeNotFoundException e) {
            throw new DeadNodeException(originalNodeId);
        }
        /* Make sure caller has permission to write to this Node */
        FilesNodePath originalNodePath = (FilesNodePath) originalMetadata.getNodePath();
        checkCallerPermission(Privilege.EDITOR, originalNodePath);

        /* Make sure original Node is locked by the caller */
        String callerId = getCurrentUser().getUserId();
        if (!callerId.equals(originalMetadata.getLockHolderUserId())) {
            throw new NotLockedException(originalNodeId, callerId);
        }
        
        /* Get this Node's current history, which should have at least one entry since the initial
         * checkout operation creates an initial revision based on the state of editing at that
         * time.
         * 
         * We can then make sure that the new version number is suitable.
         */
        NodeInternalId originalInternalId = originalMetadata.getInternalId();
        HistoryNodePath[] historyNodes = getHistoryNodes(originalMetadata.getInternalId());
        if (historyNodes.length>0) {
            /* Make sure this new revision is bigger than the last history */
            HistoryNodePath lastCommit = historyNodes[historyNodes.length - 1];
            if (versionNumber.compareTo(lastCommit.getVersionNumber()) <= 0) {
                throw new IllegalArgumentException("New version number " + versionNumber
                        + " is less than the last committed version number " + lastCommit);
            }
        }
        
        /* ==== Now that caller identity and arguments have been verified, we can make changes! ==== */
        
        /* First of all, invalidate the original Files Node */
        doStartDependencyGraphTraversal(originalMetadata, NodeDependencyType.INVALIDATE_SOURCE_ON_TARGET_CHANGE);

        /* Create new revision and copy all EDITABLE Resources to it */
        HistoryNodePath newCommitPath = new HistoryNodePath(originalInternalId, versionNumber);
        FullNodeMetadata historyMetadata = ensureCopySingleNode(workspaceInternalId,
                ResourcePathFilter.EDITABLE_FILTER, newCommitPath, null);

        /* Update metadata for new history Node to reflect the given commit details */
        updateRevisionMetadata(historyMetadata, timestamp, callerId, versionNumber,
                commitComment, false);

        /* Update the live Node's metadata using properties from the workspace. Essentially,
         * we'll just make a copy of the workspace metadata with the original Node's link ID, path
         * and internal ID. Then we'll update its revision information and save the results.
         */
        FullNodeMetadata updatedOriginalMetadata = MetadataUtilities.createCopyTemplate(workspaceMetadata,
                originalNodePath, originalMetadata.getLinkId(),
                originalMetadata.getCreationTime(), originalMetadata.getCreatorUserId());
        updatedOriginalMetadata.setInternalId(originalInternalId);

        /* Make cancel out the locking information */
        if (unlockOriginalNode) {
            updatedOriginalMetadata.setLockTime(null);
            updatedOriginalMetadata.setLockHolderUserId(null);
        }

        /* Update original Node's metadata to include version details. We will also touch its
         * modified time here as well.
         */
        updateRevisionMetadata(updatedOriginalMetadata, timestamp, callerId, versionNumber,
                commitComment, true);

        /* Copy all non-cached Resources from the Workspace Node to live Node, deleting what is
         * already there.
         * 
         * We don't copy cached Resources as web Resources may contain relativised paths which will
         * need to be recalculated after the copy.
         */
        deleteResources(originalNodePath);
        copyResources(workspaceNodePath, ResourcePathFilter.NON_CACHED_FILTER, originalNodePath);
        
        /* Finally we need to copy dependencies on the Workspace Node over */
        NodeDependencyWithTargetInfo[] workspaceDeps = nodeDependencyDao.getDependenciesWithSource(workspaceInternalId);
        Map<NodeInternalId, NodeDependencyType> copiedDeps = new HashMap<NodeInternalId, NodeDependencyType>();
        for (NodeDependencyWithTargetInfo workspaceDep : workspaceDeps) {
            copiedDeps.put(workspaceDep.getTargetNodeId(), workspaceDep.getDependencyType());
        }
        nodeDependencyDao.setDependenciesForSource(originalInternalId, copiedDeps);

        /* Return the updated version of the original Node's metadata */
        return new FullNodeMetadata[] { updatedOriginalMetadata, historyMetadata, workspaceMetadata };
    }

    //------------------------------------------------------
    // Implementation of abandonEdits()

    public FullNodeMetadata abandonEdits(WorkspaceNodeIdentifier workspaceNodeId) throws NodeNotFoundException, NotAllowedException {
        ensureNotNull(workspaceNodeId);

        /* Look up the metadata of the workspace Node */
        FullNodeMetadata workspaceNodeMetadata = doGetFullNodeMetadata(workspaceNodeId);
        WorkspaceNodePath workspaceNodePath = (WorkspaceNodePath) workspaceNodeMetadata.getNodePath();
        
        /* Make sure workspace current User has EDITOR Privileges on workspace Node */
        checkCallerPermission(Privilege.EDITOR, workspaceNodePath);

        /* Look up the original Node being edited and unlock it, if found */
        NodeInternalId originalNodeId = workspaceNodePath.getFilesNodeId();
        FullNodeMetadata result = null;
        try {
            result = doGetFullNodeMetadata(originalNodeId);
            String currentLockHolder = result.getLockHolderUserId();
            if (currentLockHolder!=null && currentLockHolder.equals(getCurrentUser().getUserId())) {
                result.setLockHolderUserId(null);
                result.setLockTime(null);
                expectUpdateFullMetadata(result);
            }
            else {
                log.warn("Node being unlocked does not correspond to original workspace Node - not unlocking");
            }
        }
        catch (NodeNotFoundException e) {
            /* That's OK! */
        }
        
        /* Finally delete the workspace Node, killing off any dependencies emanating from it */
        doDeleteWorkspaceNode(workspaceNodeMetadata);

        /* That's it! */
        return result;
    }
    
    /**
     * Internal method correctly delete a Workspace Node without checking permissions on it.
     * 
     * @param workspaceNodeMetadata metadata of the WS Node to be deleted, if it is known.
     * @throws NodeNotFoundException
     */
    protected void doDeleteWorkspaceNode(FullNodeMetadata workspaceNodeMetadata) throws NodeNotFoundException {
        /* This deletion will only delete the Node itself since it can have no children */
        List<ContentNodePath> singleNodeList = new ArrayList<ContentNodePath>();
        singleNodeList.add(workspaceNodeMetadata.getNodePath());
        doDeleteNode(workspaceNodeMetadata, singleNodeList, false);
    }
    
    //------------------------------------------------------
    // Implementations of saveResource() and deleteResource()

    public FullNodeMetadata saveResource(ResourcePath resourcePath, InputStream resourceDataStream)
            throws IOException, NodeNotFoundException,
            NotAllowedException, InappropriateResourceTypeException {
        ensureNotNull(resourcePath);
        ConstraintUtilities.ensureNotNull(resourceDataStream, "Resource InputStream");
        
        /* Set things up */
        FullNodeMetadata result = doSaveOrDeleteResourceSetup(resourcePath);

        /* Now save the resource */
        resourceManager.saveResource(resourcePath, resourceDataStream);

        return result;
    }
    
    public FullNodeMetadata deleteResource(ResourcePath resourcePath)
            throws NodeNotFoundException, ResourceNotFoundException,
            NotAllowedException, InappropriateResourceTypeException {
        ensureNotNull(resourcePath);
        
        /* Set things up */
        FullNodeMetadata result = doSaveOrDeleteResourceSetup(resourcePath);

        /* Delete the Resource */
        resourceManager.deleteResource(resourcePath);
        return result;
    }
    
    /**
     * Helper used by {@link #saveResource(ResourcePath, InputStream)}
     * and {@link #deleteResource(ResourcePath)} to read in and touch the metadata
     * of the Node owning the Resource being modified if the Resource is EDITABLE.
     * Caller permissions are also checked here.
     * 
     * @param resourcePath
     * @return possibly touched metadata of the Node being updated.
     * @throws NotAllowedException
     * @throws NodeNotFoundException
     * @throws InappropriateResourceTypeException
     */
    private FullNodeMetadata doSaveOrDeleteResourceSetup(ResourcePath resourcePath)
            throws NotAllowedException, NodeNotFoundException, InappropriateResourceTypeException {
        /* Check that the caller is allowed to change this resource. The actual permission checking
         * here is a bit more complicated than normal as users with the VIEWER Privilege are allowed
         * to save certain types of Resources (e.g. those created during the viewing or validation
         * process).
         */
        ResourceType resourceType = resourcePath.getResourceName().getResourceType();
        if (resourceType.getProductionType()==ResourceProductionType.EDITABLE) {
            checkCallerPermission(Privilege.EDITOR, resourcePath.getNodePath());
        }
        else {
            checkCallerPermission(Privilege.VIEWER, resourcePath.getNodePath());
        }
        if (log.isDebugEnabled()) {
            log.debug("Saving resource to " + resourcePath);
        }

        /* Read in the target Node's metadata, touching it if we are changing EDITABLE
         * Resources.
         * This will throw NodeNotFoundException if the target Node does not exist
         */
        FullNodeMetadata metadata = touchMetadataIfResourceEditable(resourcePath);
        if (!metadata.getNodeType().isAllowableResourceType(resourceType)) {
            throw new InappropriateResourceTypeException(metadata.getNodeType(), resourceType);
        }
        /* Now let caller finish off */
        return metadata;
    }

    //------------------------------------------------------
    // Implementations of invalidateNode() and deleteCachedResources
    
    public void invalidateNode(ContentNodeIdentifier nodeIdentifier)
            throws NodeNotFoundException, NotAllowedException {
        startDependencyGraphTraversal(nodeIdentifier, NodeDependencyType.INVALIDATE_SOURCE_ON_TARGET_CHANGE);
    }
    
    public void deleteCachedResources(ContentNodeIdentifier nodeIdentifier)
            throws NodeNotFoundException, NotAllowedException {
        startDependencyGraphTraversal(nodeIdentifier, NodeDependencyType.DELETE_CACHED_VIEWS_OF_SOURCE_ON_TARGET_CHANGE);
    }
    
    protected void startDependencyGraphTraversal(ContentNodeIdentifier nodeIdentifier, NodeDependencyType action)
            throws NodeNotFoundException, NotAllowedException {
        /* Check arguments */
        ensureNotNull(nodeIdentifier);
        
        /* Need to get the path of the Node request in order to check privileges */
        CoreNodeMetadata coreNodeMetadata = doGetCoreNodeMetadata(nodeIdentifier);
        checkCallerPermission(Privilege.VIEWER, coreNodeMetadata.getNodePath());

        /* Now do the traversal */
        doStartDependencyGraphTraversal(coreNodeMetadata, action);
    }
    
    /**
     * Works out and then traverses a route through the "depends-on" tree starting at the
     * Target Node with the given CoreNodeMetadata startNodeMetadata.
     * <p>
     * We're cheating a bit here and using one of the values of
     * {@link NodeDependencyType}, even though that doesn't really correspond
     * to an "action" as follows:
     * <ul>
     *   <li>
     *     {@link NodeDependencyType#INVALIDATE_SOURCE_ON_TARGET_CHANGE} means invalidate the
     *     given Node and then traverse dependents.
     *   </li>
     *   </li>
     *     {@link NodeDependencyType#DELETE_CACHED_VIEWS_OF_SOURCE_ON_TARGET_CHANGE} means
     *     kill off cached Resources under the given Node and then traverse dependents
     *     of type {@link NodeDependencyType#DELETE_CACHED_VIEWS_OF_SOURCE_ON_TARGET_CHANGE}.
     *   </li>
     * </ul>
     * We'll try to only visit Nodes once. However, if we visit a Node with action=='C' and
     * then find we need to visit it with action=='V' then we will revisit it.
     * 
     * @param startNodeMetadata metadata for the Node to start traversing at.
     * @param action represents what to do to the Node, see above.
     */
    protected void doStartDependencyGraphTraversal(CoreNodeMetadata startNodeMetadata,
            NodeDependencyType action) {
        /* First of all we'll work out which Nodes we need to visit. We'll build this
         * up in a Map of NodeInternalId -> NodeDependencyType. We also need to keep
         * track of NodePaths so create a NodeInternalId -> ContentNodePath map as well.
         */
        Map<NodeInternalId, NodeDependencyType> holidayPlan = new TreeMap<NodeInternalId, NodeDependencyType>();
        Map<NodeInternalId, ContentNodePath> nodePathMap = new HashMap<NodeInternalId, ContentNodePath>();
        buildHolidayPlan(holidayPlan, nodePathMap, startNodeMetadata, action);
        
        /* Maybe log what is about to happen */
        NodeInternalId nodeId;
        NodeDependencyType toDo;
        if (log.isInfoEnabled()) {
            StringBuilder logBuilder = new StringBuilder("Dependency traversal starting at ")
                .append(startNodeMetadata.getNodePath())
                .append(" will make the following changes:");
            for (Entry<NodeInternalId, NodeDependencyType> toVisit : holidayPlan.entrySet()) {
                nodeId = toVisit.getKey();
                toDo = toVisit.getValue();
                logBuilder.append("\n  ")
                    .append(nodePathMap.get(nodeId))
                    .append(" (")
                    .append(toDo==NodeDependencyType.DELETE_CACHED_VIEWS_OF_SOURCE_ON_TARGET_CHANGE ? "Delete Cached Views" : "")
                    .append(toDo==NodeDependencyType.INVALIDATE_SOURCE_ON_TARGET_CHANGE ? "Invalidate" : "")
                    .append(")");
            }
            log.info(logBuilder);
        }
        /* Now we go through each Node and do whatever is required to them */
        for (Entry<NodeInternalId, NodeDependencyType> toVisit : holidayPlan.entrySet()) {
            nodeId = toVisit.getKey();
            visitDependencyTreeNode(nodeId, nodePathMap.get(nodeId), toVisit.getValue());
        }
    }
    
    /**
     * Used by {@link #doStartDependencyGraphTraversal(CoreNodeMetadata, NodeDependencyType)}, this
     * traverses all of the Nodes using the recipe stated there to determine which Nodes need to
     * be invalidated and/or purged.
     * <p>
     * This works recursively to build up the "holiday plan"(!) of what needs done.
     * 
     * @param holidayPlan Map maintaining information about which Nodes to visit
     * @param nodePathMap NodeInternalId -> ContentNodePath map for each Node that will be visited
     * @param currentNodeMetadata metadata for the current Node being visited
     * @param action action to perform on current Node.
     */
    private void buildHolidayPlan(Map<NodeInternalId, NodeDependencyType> holidayPlan,
            Map<NodeInternalId, ContentNodePath> nodePathMap,
            CoreNodeMetadata currentNodeMetadata,
            NodeDependencyType action) {
        /* We're visiting this Node */
        NodeInternalId currentNodeId = currentNodeMetadata.getInternalId();
        holidayPlan.put(currentNodeId, action);
        nodePathMap.put(currentNodeId, currentNodeMetadata.getNodePath());
        
        /* Get information about all Nodes that have dependencies on this target */
        NodeDependencyWithSourceInfo[] deps = nodeDependencyDao.getDependenciesWithTarget(currentNodeId);
        
        /* Now visit certain dependents that we haven't already traversed */
        boolean shouldVisitDependent;
        CoreNodeMetadata depMetadata;
        NodeInternalId depId;
        NodeDependencyType depType;
        for (NodeDependencyWithSourceInfo dep : deps) {
            /* We'll visit this dependency source if:
             * 
             * (Source hasn't been visited yet
             *    OR (Source has been visited with action 'C' and dependency type is 'V')
             * ) AND (Current action is 'V' OR Current action is 'C' and dependency type is 'C')
             * 
             * The last condition here is currently equivalent to
             * !(Current action=='C' AND dependent_type=='V')
             * since dependency type is binary.
             */
            depMetadata = dep.getSourceNodeMetadata();
            depId = depMetadata.getInternalId();
            depType = dep.getDependencyType();
            shouldVisitDependent = 
                (!holidayPlan.containsKey(depId)
                        || (holidayPlan.get(depId)==NodeDependencyType.DELETE_CACHED_VIEWS_OF_SOURCE_ON_TARGET_CHANGE
                            && depType==NodeDependencyType.INVALIDATE_SOURCE_ON_TARGET_CHANGE))
                && !(action==NodeDependencyType.DELETE_CACHED_VIEWS_OF_SOURCE_ON_TARGET_CHANGE
                        && depType==NodeDependencyType.INVALIDATE_SOURCE_ON_TARGET_CHANGE);
            if (shouldVisitDependent) {
                buildHolidayPlan(holidayPlan, nodePathMap, depMetadata, depType);
            }
        }
    }
    
    private void visitDependencyTreeNode(NodeInternalId nodeId,
            ContentNodePath nodePath, NodeDependencyType action) {
        switch(action) {
            case INVALIDATE_SOURCE_ON_TARGET_CHANGE:
                /* Invalidate Node and kill of this Node's forward dependencies */
                log.debug("Invalidating Node at " + nodePath);
                ensureDeleteResources(ResourcePathFilter.MANAGED_FILTER, nodePath);
                nodeDependencyDao.setDependenciesForSource(nodeId, null);
                break;
                
            case DELETE_CACHED_VIEWS_OF_SOURCE_ON_TARGET_CHANGE:
                /* Just delete cached views */
                log.debug("Removing cached views of Node at " + nodePath);
                ensureDeleteResources(ResourcePathFilter.DYNAMIC_FILTER, nodePath);
                break;
                
            default:
                throw new ContentManagerException("Unexpected switch case");
        }
    }
    
    /**
     * Helper to ensure that a subset of (assumed non-editable) Resources at the given nodePath
     * are safely deleted, without checking permissions.
     * 
     * @param filter
     * @param nodePath
     */
    private void ensureDeleteResources(LambdaFilter<ResourcePath> filter, ContentNodePath nodePath) {
        try {
            Collection<ResourcePath> toDelete = filter.apply(resourceManager.getResourcePaths(nodePath));
            for (ResourcePath condemned : toDelete) {
                try {
                    resourceManager.deleteResource(condemned);
                }
                catch (ResourceNotFoundException e) {
                    /* Can only happen under concurrent modification! */
                    log.warn("Resource at " + condemned + " already deleted - concurrency issues?", e);
                }
            }
        }
        catch (NodeNotFoundException e) {
            fireUnexpectedException(e);
        }
    }
    
    //------------------------------------------------------
    // General Helper Methods
    
    /**
     * Helper method that "touches" the metadata of the given Node to indicate that the
     * details have changed. (I.e. modification properties get updated.) The revised
     * metadata is returned.
     *
     * @param nodeIdentifier identifies the Node to be touched.
     * @return touched metadata
     * @throws NodeNotFoundException
     */
    protected FullNodeMetadata touchMetadata(ContentNodeIdentifier nodeIdentifier)
            throws NodeNotFoundException {
        FullNodeMetadata metadata = doGetFullNodeMetadata(nodeIdentifier);
        MetadataUtilities.touchMetadata(metadata, createTimestamp(), getCurrentUser().getUserId());
        try {
            metadataManager.updateNodeMetadata(metadata);
        }
        catch (DuplicateNodePathException e) {
            /* Can't happen as we explicitly checked for this */
            fireUnexpectedException(e);
        }
        catch (ParentNodeNotFoundException e) {
            /* Can't happen */
            fireUnexpectedException(e);
        }
        catch (DuplicateNodeLinkIdException e) {
            /* Can't happen */
            fireUnexpectedException(e);
        }
        catch (ParentNodeCannotHaveChildrenException e) {
            /* Can't happen */
            fireUnexpectedException(e);
        }
        catch (NodePathCircularityException e) {
            /* Can't happen */
            fireUnexpectedException(e);
        }
        return metadata;
    }

    /**
     * Helper method that returns the metadata of the Node owning the given Resource,
     * touching its modification time if the Resource is editable.
     * <p>
     * This is useful when making updates to Resources.
     *
     * @param resourcePath identifies the Resource being updated.
     * @return touched metadata
     * @throws NodeNotFoundException
     */
    protected FullNodeMetadata touchMetadataIfResourceEditable(ResourcePath resourcePath)
            throws NodeNotFoundException {
        ContentNodePath nodePath = resourcePath.getNodePath();
        ResourceProductionType productionType = resourcePath.getResourceName().getResourceType().getProductionType();
        FullNodeMetadata result;
        if (productionType==ResourceProductionType.EDITABLE) {
            result = touchMetadata(resourcePath.getNodePath());
        }
        else {
            result = doGetFullNodeMetadata(nodePath);
        }
        return result;
    }
    
    /**
     * Helper method that applies the given revision information to the Node's metadata, changing
     * the metadata Object in place and saving the results.
     * <p>
     * It optionally updates the Node's modification time if required.
     */
    protected void updateRevisionMetadata(FullNodeMetadata originalMetadata,
            Date commitTime, String committerUserId,
            VersionNumber versionNumber,
            String commitComment, boolean touchModificationData) {
        MetadataUtilities.applyRevision(originalMetadata, commitTime, committerUserId,
                versionNumber, commitComment);
        if (touchModificationData) {
            MetadataUtilities.touchMetadata(originalMetadata, commitTime, committerUserId);
        }
        expectUpdateFullMetadata(originalMetadata);
    }

    /**
     * Helper method to directly apply a metadata update, expecting success.
     * Any failures are rethrown as "unexpected" Exceptions.
     *
     * @param updatedMetadata
     */
    protected void expectUpdateFullMetadata(FullNodeMetadata updatedMetadata) {
        try {
            metadataManager.updateNodeMetadata(updatedMetadata);
        }
        catch (Exception e) {
            fireUnexpectedException(e);
        }
    }

    /**
     * Helper method to get the history Nodes for the given <code>files/...</code> Node. This
     * will return an empty array if no history has yet been created.
     *
     * @param nodeId
     * 
     * @return Array of History Node paths, sorted in version number order. This will be empty if
     *   no history has yet been stored for this Node.
     */
    protected HistoryNodePath[] getHistoryNodes(NodeInternalId nodeId) {
        NodePath historyFolderPath = NodePath.createHistoryContainer(nodeId);
        HistoryNodePath[] result = null;
        try {
            NodePath[] childNodePaths = resourceManager.getChildNodePaths(historyFolderPath);
            result = new HistoryNodePath[childNodePaths.length];
            for (int i=0; i<childNodePaths.length; i++) {
                result[i] = (HistoryNodePath) childNodePaths[i];
            }
            /* Sort to ensure that results are in increasing order */
            Arrays.sort(result);
        }
        catch (NodeNotFoundException e) {
            /* No history stored so return empty array */
            result = new HistoryNodePath[0];
        }
        return result;
    }

    /**
     * Helper method to delete all Resources stored by a Node.
     */
    protected void deleteResources(ContentNodePath nodePath) {
        if (log.isDebugEnabled()) {
            log.debug("Deleting resources at " + nodePath);
        }
        try {
            ResourcePath[] sourceResources = resourceManager.getResourcePaths(nodePath);
            for (ResourcePath resourcePath : sourceResources) {
                resourceManager.deleteResource(resourcePath);
            }
        }
        catch (Exception e) {
            fireUnexpectedException(e);
        }
    }


    /**
     * This method creates the timestamp for various operations. I've made
     * this protected so that it can be overridden during testing to return
     * something more constant so that we can test easier.
     */
    protected Date createTimestamp() {
        return new Date();
    }

    /**
     * Handy method used to rethrow an Exception as a {@link ContentManagerException}
     * if something unexpected happens. If the Exception is already a
     * {@link ContentManagerException} then it is thrown as-is.
     *
     * @param e Throwable to be propagated.
     *
     * @throws ContentManagerException
     */
    protected void fireUnexpectedException(Throwable e) {
        if (e instanceof ContentManagerException) {
            throw (ContentManagerException) e;
        }
        log.error("An unexpected Exception occurred", e);
        throw new ContentManagerException("Unexpected exception", e);
    }
}
